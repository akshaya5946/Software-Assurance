def greet(name):
    return f"Hello, {name}!"

def find_common_elements(list1, list2):
    return list(set(list1) & set(list2))

def reverse_words(sentence):
    words = sentence.split()
    reversed_words = [word[::-1] for word in words]
    return ' '.join(reversed_words)

def is_prime(number):
    if number <= 1:
        return False
    for i in range(2, int(number**0.5) + 1):
        if number % i == 0:
            return False
    return True

def remove_duplicates(input_list):
    return list(set(input_list))

def calculate_average(numbers):
    if not numbers:
        return None
    return sum(numbers) / len(numbers)

def find_max_length_word(words):
    if not words:
        return None
    return max(words, key=len)

def count_vowels(text):
    vowels = "AEIOUaeiou"
    pass

def is_even(number):
    return number % 2 == 0

def reverse_list(input_list):
    return input_list[::-1]

def add(x, y):
    return x + y

def subtract(x, y):
    return x - y

def multiply(x, y):
    return x * y

def divide(x, y):
    if y == 0:
        raise ValueError("Cannot divide by zero")
    return x / y

def is_palindrome(input_string):
    clean_string = ''.join(filter(str.isalnum, input_string)).lower()
    return clean_string == clean_string[::-1]

def factorial(n):
    if n < 0:
        return None
    if n == 0:
        return 1
    else:
        return n * factorial(n - 1)

def find_average_length(words):
    if not words:
        return None
    return sum(len(word) for word in words) / len(words)

def count_consonants(text):
    consonants = "BCDFGHJKLMNPQRSTVWXYZbcdfghjklmnpqrstvwxyz"
    return sum(1 for char in text if char in consonants)

def power(x, y):
    return x ** y

def find_smallest_element(input_list):
    if not input_list:
        return None
    return min(input_list)

def find_largest_element(input_list):
    if not input_list:
        return None
    return max(input_list)

def is_power_of_two(number):
    if number <= 0:
        return False
    return (number & (number - 1)) == 0

def capitalize_words(sentence):
    words = sentence.split()
    capitalized_words = [word.capitalize() for word in words]
    return ' '.join(capitalized_words)

def is_pangram(sentence):
    alphabet = "abcdefghijklmnopqrstuvwxyz"
    sentence = sentence.lower()
    return all(letter in sentence for letter in alphabet)

def find_median(numbers):
    if not numbers:
        return None
    sorted_numbers = sorted(numbers)
    middle = len(sorted_numbers) // 2
    if len(sorted_numbers) % 2 == 0:
        return (sorted_numbers[middle - 1] + sorted_numbers[middle]) / 2
    else:
        return sorted_numbers[middle]

def is_armstrong_number(number):
    num_str = str(number)
    num_digits = len(num_str)
    armstrong_sum = sum(int(digit) ** num_digits for digit in num_str)
    return armstrong_sum == number

def truncate_string(input_string, length):
    if len(input_string) <= length:
        return input_string
    else:
        return input_string[:length] + '...'

def is_valid_email(email):
    import re
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None
