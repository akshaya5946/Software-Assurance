import unittest
from utils import *

class TestMyFunctions(unittest.TestCase):

    def test_greet(self):
        self.assertEqual(greet("Alice"), "Hello, Alice!")
        self.assertEqual(greet("Bob"), "Hello, Bob!")

    def test_find_common_elements(self):
        self.assertEqual(find_common_elements([1, 2, 3], [2, 3, 4]), [2, 3])
        self.assertCountEqual(find_common_elements(['a', 'b', 'c'], ['b', 'c', 'd']), ['b', 'c'])
        self.assertEqual(find_common_elements([], [1, 2, 3]), [])

    def test_reverse_words(self):
        self.assertEqual(reverse_words("Hello World"), "olleH dlroW")
        self.assertEqual(reverse_words("Python is great"), "nohtyP si taerg")

    def test_is_prime(self):
        self.assertTrue(is_prime(2))
        self.assertTrue(is_prime(7))
        self.assertFalse(is_prime(4))
        self.assertFalse(is_prime(1))
        self.assertFalse(is_prime(0))

    def test_remove_duplicates(self):
        self.assertEqual(remove_duplicates([1, 2, 2, 3, 4, 4]), [1, 2, 3, 4])
        self.assertCountEqual(remove_duplicates(['a', 'b', 'b', 'c', 'c']), ['a', 'b', 'c'])
        self.assertEqual(remove_duplicates([]), [])

    def test_calculate_average(self):
        self.assertEqual(calculate_average([1, 2, 3, 4, 5]), 3.0)
        self.assertEqual(calculate_average([10, 20, 30]), 20.0)
        self.assertIsNone(calculate_average([]))

    def test_find_max_length_word(self):
        self.assertEqual(find_max_length_word(["apple", "banana", "cherry"]), "banana")
        self.assertEqual(find_max_length_word(["dog", "elephant", "cat"]), "elephant")
        self.assertIsNone(find_max_length_word([]))

    def test_count_vowels(self):
        self.assertEqual(count_vowels("Hello World"), 3)
        self.assertEqual(count_vowels("Python is great"), 4)
        self.assertEqual(count_vowels("Rhythm"), 0)

    def test_is_even(self):
        self.assertTrue(is_even(2))
        self.assertTrue(is_even(0))
        self.assertFalse(is_even(1))
        self.assertFalse(is_even(7))

    def test_reverse_list(self):
        self.assertEqual(reverse_list([1, 2, 3]), [3, 2, 1])
        self.assertEqual(reverse_list(['a', 'b', 'c']), ['c', 'b', 'a'])
        self.assertEqual(reverse_list([]), [])

    def test_add(self):
        self.assertEqual(add(2, 3), 5)
        self.assertEqual(add(-1, 1), 0)
        self.assertEqual(add(0, 0), 0)

    def test_subtract(self):
        self.assertEqual(subtract(5, 3), 2)
        self.assertEqual(subtract(1, -1), 2)
        self.assertEqual(subtract(0, 0), 0)

    def test_multiply(self):
        self.assertEqual(multiply(2, 3), 6)
        self.assertEqual(multiply(-1, 4), -4)
        self.assertEqual(multiply(0, 7), 0)

    def test_divide(self):
        self.assertEqual(divide(6, 3), 2)
        self.assertEqual(divide(5, -2), -2.5)
        self.assertEqual(divide(0, 5), 0)

        with self.assertRaises(ValueError):
            divide(1, 0)

    def test_is_palindrome(self):
        self.assertTrue(is_palindrome("racecar"))
        self.assertTrue(is_palindrome("A man, a plan, a canal, Panama"))
        self.assertFalse(is_palindrome("hello"))
        self.assertTrue(is_palindrome(""))
        
    def test_factorial(self):
        self.assertEqual(factorial(0), 1)
        self.assertEqual(factorial(1), 1)
        self.assertEqual(factorial(5), 120)
        self.assertIsNone(factorial(-1))
        
    def test_find_average_length(self):
        self.assertAlmostEqual(find_average_length(["apple", "banana", "cherry"]), 5.666666666666667, places=6)
        self.assertAlmostEqual(find_average_length(["dog", "elephant", "cat"]), 4.666666666666667, places=6)
        self.assertIsNone(find_average_length([]))

    def test_count_consonants(self):
        self.assertEqual(count_consonants("Hello World"), 7)
        self.assertEqual(count_consonants("Python is great"), 9) 
        self.assertEqual(count_consonants("Rhythm"), 6)

    def test_power(self):
        self.assertEqual(power(2, 3), 8)
        self.assertEqual(power(5, 0), 1)
        self.assertEqual(power(3, -1), 0.3333333333333333)

    def test_find_smallest_element(self):
        self.assertEqual(find_smallest_element([3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5]), 1)
        self.assertEqual(find_smallest_element(['a', 'c', 'b']), 'a')
        self.assertIsNone(find_smallest_element([]))

    def test_find_largest_element(self):
        self.assertEqual(find_largest_element([3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5]), 9)
        self.assertEqual(find_largest_element(['a', 'c', 'b']), 'c')
        self.assertIsNone(find_largest_element([]))

    def test_is_power_of_two(self):
        self.assertTrue(is_power_of_two(1))
        self.assertTrue(is_power_of_two(2))
        self.assertTrue(is_power_of_two(16))
        self.assertFalse(is_power_of_two(0))
        self.assertFalse(is_power_of_two(3))
        self.assertFalse(is_power_of_two(15))

    def test_capitalize_words(self):
        self.assertEqual(capitalize_words("hello world"), "Hello World")
        self.assertEqual(capitalize_words("python is great"), "Python Is Great")

    def test_is_pangram(self):
        self.assertTrue(is_pangram("The quick brown fox jumps over the lazy dog"))
        self.assertTrue(is_pangram("Pack my box with five dozen liquor jugs"))
        self.assertFalse(is_pangram("Hello, World!"))

    def test_find_median(self):
        self.assertEqual(find_median([1, 3, 5]), 3)
        self.assertEqual(find_median([10, 2, 8, 4, 6]), 6)
        self.assertEqual(find_median([7]), 7)

    def test_is_armstrong_number(self):
        self.assertTrue(is_armstrong_number(153))
        self.assertTrue(is_armstrong_number(9474))
        self.assertTrue(is_armstrong_number(370))
        self.assertFalse(is_armstrong_number(123))

    def test_truncate_string(self):
        self.assertEqual(truncate_string("Hello, World!", 5), "Hello...")
        self.assertEqual(truncate_string("Python is great", 10), "Python is ...")
        self.assertEqual(truncate_string("Short", 10), "Short")

    def test_is_valid_email(self):
        self.assertTrue(is_valid_email("user@example.com"))
        self.assertTrue(is_valid_email("test.user@subdomain.example.co.uk"))
        self.assertFalse(is_valid_email("invalid-email"))
        self.assertFalse(is_valid_email("user@.com"))
        self.assertFalse(is_valid_email("user@example"))
        self.assertFalse(is_valid_email("@example.com"))
        self.assertFalse(is_valid_email("user@.com."))

if __name__ == '__main__':
    unittest.main()
